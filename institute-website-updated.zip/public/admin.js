document.addEventListener('DOMContentLoaded', () => {
  const addCertForm = document.getElementById('addCertForm');
  const addMsg = document.getElementById('addCertMessage');
  const refreshBtn = document.getElementById('refreshCerts');
  const tbody = document.querySelector('#certTable tbody');

  async function loadCertificates() {
    tbody.innerHTML = '<tr><td colspan="4">Loading...</td></tr>';
    try {
      const res = await fetch('/api/certificates');
      if (!res.ok) {
        tbody.innerHTML = '<tr><td colspan="4">Error loading certificates</td></tr>';
        return;
      }
      const data = await res.json();
      if (!data.length) {
        tbody.innerHTML = '<tr><td colspan="4">No certificates found</td></tr>';
        return;
      }
      tbody.innerHTML = '';
      data.forEach(cert => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td>${cert.certificateId}</td>
          <td>${cert.studentName}</td>
          <td>${cert.courseName}</td>
          <td>${cert.issueDate}</td>
        `;
        tbody.appendChild(tr);
      });
    } catch (err) {
      tbody.innerHTML = '<tr><td colspan="4">Error loading certificates</td></tr>';
    }
  }

  if (addCertForm) {
    addCertForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      addMsg.textContent = 'Saving...';
      const formData = new FormData(addCertForm);
      const data = Object.fromEntries(formData.entries());
      try {
        const res = await fetch('/api/certificates', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(data)
        });
        const json = await res.json();
        if (json.success) {
          addMsg.textContent = 'Certificate saved!';
          addCertForm.reset();
          loadCertificates();
        } else {
          addMsg.textContent = json.message || 'Error saving certificate.';
        }
      } catch (err) {
        addMsg.textContent = 'Error saving certificate.';
      }
    });
  }

  if (refreshBtn) {
    refreshBtn.addEventListener('click', loadCertificates);
    loadCertificates();
  }
});
