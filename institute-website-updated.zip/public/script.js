document.addEventListener('DOMContentLoaded', () => {
  const yearSpan = document.getElementById('year');
  if (yearSpan) yearSpan.textContent = new Date().getFullYear();

  const enquiryForm = document.getElementById('enquiryForm');
  if (enquiryForm) {
    enquiryForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const formData = new FormData(enquiryForm);
      const data = Object.fromEntries(formData.entries());
      const msg = document.getElementById('enquiryMessage');
      const waLink = document.getElementById('waLink');
      msg.textContent = 'Submitting...';

      try {
        const res = await fetch('/api/enquiry', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(data)
        });
        const json = await res.json();
        if (json.success) {
          msg.textContent = 'Enquiry submitted successfully! You can also chat with us on WhatsApp.';
          // Build WhatsApp link with enquiry details
          const text = `Hello, I am ${data.name}. I have submitted an enquiry from the website for course: ${data.course}. My phone number is ${data.phone}.`;
          const url = `https://wa.me/916264776175?text=${encodeURIComponent(text)}`;
          if (waLink) {
            waLink.href = url;
            waLink.classList.remove('hidden');
          }
          enquiryForm.reset();
        } else {
          msg.textContent = json.message || 'Something went wrong.';
        }
      } catch (err) {
        msg.textContent = 'Error submitting enquiry.';
      }
    });
  }

  const verifyForm = document.getElementById('verifyForm');
  if (verifyForm) {
    verifyForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const formData = new FormData(verifyForm);
      const data = Object.fromEntries(formData.entries());
      const msg = document.getElementById('verifyMessage');
      const details = document.getElementById('certificateDetails');
      const downloadBtn = document.getElementById('downloadCert');
      msg.textContent = 'Verifying...';
      details.classList.add('hidden');

      try {
        const res = await fetch('/api/verify-certificate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(data)
        });
        const json = await res.json();
        if (json.success) {
          msg.textContent = 'Certificate found!';
          document.getElementById('certId').textContent = json.certificate.certificateId;
          document.getElementById('certStudent').textContent = json.certificate.studentName;
          document.getElementById('certCourse').textContent = json.certificate.courseName;
          document.getElementById('certDate').textContent = json.certificate.issueDate;
          if (downloadBtn) {
            downloadBtn.href = `/certificate/${encodeURIComponent(json.certificate.certificateId)}/download`;
          }
          details.classList.remove('hidden');
        } else {
          msg.textContent = json.message || 'Certificate not found.';
        }
      } catch (err) {
        msg.textContent = 'Error verifying certificate.';
      }
    });
  }
});
