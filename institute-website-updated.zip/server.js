const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const fs = require('fs');
const path = require('path');
const nodemailer = require('nodemailer');
const { v4: uuidv4 } = require('uuid');
const PDFDocument = require('pdfkit');

const app = express();
const PORT = process.env.PORT || 3000;

// ====== BASIC CONFIG ======
const ADMIN_USER = process.env.ADMIN_USER || 'admin';
const ADMIN_PASS = process.env.ADMIN_PASS || 'password';

// Configure your SMTP details via environment variables
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || 'smtp.example.com',
  port: process.env.SMTP_PORT ? parseInt(process.env.SMTP_PORT) : 587,
  secure: process.env.SMTP_SECURE === 'true',
  auth: {
    user: process.env.SMTP_USER || 'your-email@example.com',
    pass: process.env.SMTP_PASS || 'your-smtp-password'
  }
});

// ====== MIDDLEWARE ======
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.use(session({
  secret: process.env.SESSION_SECRET || 'supersecretkey',
  resave: false,
  saveUninitialized: true
}));

app.use(express.static(path.join(__dirname, 'public')));

// ====== SIMPLE JSON "DATABASE" ======
const dataDir = path.join(__dirname, 'data');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir);

const certFile = path.join(dataDir, 'certificates.json');
const enquiryFile = path.join(dataDir, 'enquiries.json');

function readJson(file) {
  if (!fs.existsSync(file)) return [];
  try {
    const raw = fs.readFileSync(file);
    return JSON.parse(raw.toString() || '[]');
  } catch (err) {
    console.error('Error reading', file, err);
    return [];
  }
}

function writeJson(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

// ====== AUTH MIDDLEWARE ======
function requireAdmin(req, res, next) {
  if (req.session && req.session.isAdmin) {
    return next();
  }
  return res.redirect('/admin/login');
}

// ====== PUBLIC ROUTES ======

// Certificate verification API
app.post('/api/verify-certificate', (req, res) => {
  const { certificateId } = req.body;
  const certs = readJson(certFile);
  const cert = certs.find(c => c.certificateId === certificateId);
  if (!cert) {
    return res.json({ success: false, message: 'Certificate not found' });
  }
  return res.json({ success: true, certificate: cert });
});

// Download certificate as PDF
app.get('/certificate/:certificateId/download', (req, res) => {
  const { certificateId } = req.params;
  const certs = readJson(certFile);
  const cert = certs.find(c => c.certificateId === certificateId);
  if (!cert) {
    return res.status(404).send('Certificate not found');
  }

  const doc = new PDFDocument({ size: 'A4', margin: 50 });

  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `attachment; filename=certificate-${certificateId}.pdf`);

  doc.pipe(res);

  // Simple certificate layout
  doc
    .fontSize(26)
    .text('Young Engineers Computer Institute', { align: 'center' })
    .moveDown(0.3);

  doc
    .fontSize(12)
    .text('M2 Mayur Plaza, Thatipur, Gwalior (M.P.)', { align: 'center' })
    .text('Mob.: 6264776175  |  E-mail: youngengineerscomputer@gmail.com', { align: 'center' })
    .moveDown(2);

  doc
    .fontSize(22)
    .text('Certificate of Completion', { align: 'center', underline: true })
    .moveDown(2);

  doc
    .fontSize(14)
    .text(`This is to certify that`, { align: 'center' })
    .moveDown(0.5)
    .fontSize(18)
    .text(cert.studentName, { align: 'center' })
    .moveDown(0.5)
    .fontSize(14)
    .text(`has successfully completed the`, { align: 'center' })
    .moveDown(0.5)
    .fontSize(18)
    .text(cert.courseName, { align: 'center' })
    .moveDown(1.5);

  doc
    .fontSize(14)
    .text(`Issue Date: ${cert.issueDate}`, { align: 'center' })
    .moveDown(0.5)
    .text(`Certificate ID: ${cert.certificateId}`, { align: 'center' })
    .moveDown(3);

  doc
    .fontSize(14)
    .text('__________________________', 80, 600)
    .text('Authorized Signatory', 80, 620);

  doc.end();
});

// Course enquiry
app.post('/api/enquiry', async (req, res) => {
  const { name, email, phone, course, message } = req.body;
  const enquiries = readJson(enquiryFile);
  const enquiry = {
    id: uuidv4(),
    name,
    email,
    phone,
    course,
    message,
    createdAt: new Date().toISOString()
  };
  enquiries.push(enquiry);
  writeJson(enquiryFile, enquiries);

  // Send email notification to institute
  try {
    await transporter.sendMail({
      from: process.env.SMTP_FROM || process.env.SMTP_USER || 'your-email@example.com',
      to: process.env.INSTITUTE_EMAIL || 'your-email@example.com',
      subject: 'New Course Enquiry',
      text: `New enquiry received:
Name: ${name}
Email: ${email}
Phone: ${phone}
Course: ${course}
Message: ${message}`
    });
  } catch (err) {
    console.error('Error sending enquiry email:', err);
  }

  res.json({ success: true, message: 'Enquiry submitted successfully' });
});

// ====== ADMIN ROUTES ======
app.get('/admin/login', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin-login.html'));
});

app.post('/admin/login', (req, res) => {
  const { username, password } = req.body;
  if (username === ADMIN_USER && password === ADMIN_PASS) {
    req.session.isAdmin = true;
    return res.redirect('/admin/dashboard');
  }
  return res.send('<h2>Invalid credentials</h2><a href="/admin/login">Back</a>');
});

app.get('/admin/dashboard', requireAdmin, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin-dashboard.html'));
});

// API to get all certificates
app.get('/api/certificates', requireAdmin, (req, res) => {
  const certs = readJson(certFile);
  res.json(certs);
});

// API to add certificate
app.post('/api/certificates', requireAdmin, (req, res) => {
  const { studentName, courseName, issueDate, certificateId } = req.body;
  const certs = readJson(certFile);

  const finalId = certificateId && certificateId.trim() !== '' ? certificateId : uuidv4().slice(0, 8).toUpperCase();

  if (certs.find(c => c.certificateId === finalId)) {
    return res.status(400).json({ success: false, message: 'Certificate ID already exists' });
  }

  const cert = {
    certificateId: finalId,
    studentName,
    courseName,
    issueDate,
    createdAt: new Date().toISOString()
  };

  certs.push(cert);
  writeJson(certFile, certs);

  res.json({ success: true, certificate: cert });
});

// Logout
app.get('/admin/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/admin/login');
  });
});

// ====== START SERVER ======
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
